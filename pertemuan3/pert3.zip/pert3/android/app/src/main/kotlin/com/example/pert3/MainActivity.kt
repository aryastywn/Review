package com.example.pert3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
